from flask import Flask, request
import requests
import openai
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
API_URL = "https://waba.360dialog.io/v1/messages"
API_KEY = os.getenv("D360_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

openai.api_key = OPENAI_API_KEY

faq = {
    "delivery": "We offer standard and express delivery. Standard takes 3-5 business days.",
    "return": "To return an item, visit our returns page and submit a request within 30 days.",
    "payment": "We accept Visa, MasterCard, PayPal, and Apple Pay.",
    "tracking": "You'll receive a tracking link via email once your order ships.",
    "international": "Yes, we ship to most countries worldwide. Shipping costs vary by location."
}

@app.route("/webhook", methods=["POST"])
def webhook():
    data = request.json
    messages = data.get("messages", [])
    for msg in messages:
        if "text" in msg:
            sender = msg["from"]
            body = msg["text"]["body"].lower()
            print(f"From {sender}: {body}")

            reply = None
            for keyword, answer in faq.items():
                if keyword in body:
                    reply = answer
                    break

            if not reply:
                response = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "user", "content": body}]
                )
                reply = response.choices[0].message.content

            payload = {
                "to": sender,
                "type": "text",
                "text": { "body": reply }
            }

            headers = {
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json"
            }

            requests.post(API_URL, json=payload, headers=headers)
    return "OK", 200

if __name__ == "__main__":
    app.run()
