const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());

const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
const ACCESS_TOKEN = process.env.ACCESS_TOKEN;
const PHONE_NUMBER_ID = process.env.PHONE_NUMBER_ID;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

const { Configuration, OpenAIApi } = require("openai");
const configuration = new Configuration({ apiKey: OPENAI_API_KEY });
const openai = new OpenAIApi(configuration);

// Fake FAQ
const faq = {
  "delivery": "We offer standard and express delivery. Standard takes 3-5 business days.",
  "return": "To return an item, visit our returns page and submit a request within 30 days.",
  "payment": "We accept Visa, MasterCard, PayPal, and Apple Pay.",
  "tracking": "You'll receive a tracking link via email once your order ships.",
  "international": "Yes, we ship to most countries worldwide. Shipping costs vary by location."
};

app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    res.status(200).send(challenge);
  } else {
    res.sendStatus(403);
  }
});

app.post('/webhook', async (req, res) => {
  const messages = req.body.entry?.[0]?.changes?.[0]?.value?.messages;
  if (messages) {
    const msg = messages[0];
    const from = msg.from;
    const text = msg.text?.body.toLowerCase();

    let reply = null;

    for (const keyword in faq) {
      if (text.includes(keyword)) {
        reply = faq[keyword];
        break;
      }
    }

    if (!reply) {
      const completion = await openai.createChatCompletion({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: text }],
      });
      reply = completion.data.choices[0].message.content;
    }

    await axios.post(
      `https://graph.facebook.com/v18.0/${PHONE_NUMBER_ID}/messages`,
      {
        messaging_product: 'whatsapp',
        to: from,
        text: { body: reply },
      },
      {
        headers: {
          Authorization: `Bearer ${ACCESS_TOKEN}`,
          'Content-Type': 'application/json',
        },
      }
    );
  }
  res.sendStatus(200);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Meta WhatsApp AI bot listening on port ${PORT}`);
});
